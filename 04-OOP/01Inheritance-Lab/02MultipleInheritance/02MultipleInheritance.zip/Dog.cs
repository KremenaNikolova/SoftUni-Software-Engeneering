﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    internal class Dog : Animal
    {
        public void Bark()
        {
            Console.WriteLine("barking...");
        }
    }
}
