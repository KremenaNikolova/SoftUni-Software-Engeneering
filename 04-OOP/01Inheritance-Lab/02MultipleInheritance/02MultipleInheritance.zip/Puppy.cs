﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Farm
{
    internal class Puppy : Dog
    {
        public void Weep()
        {
            Console.WriteLine("weeping...");
        }
    }
}
