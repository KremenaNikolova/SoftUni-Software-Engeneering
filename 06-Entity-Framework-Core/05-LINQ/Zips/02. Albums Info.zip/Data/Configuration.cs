﻿namespace MusicHub.Data;

public static class Configuration
{
    public static string ConnectionString =
        @"Server=ARADIA;Database=MusicHub;Integrated Security=True;TrustServerCertificate=True;";
}
