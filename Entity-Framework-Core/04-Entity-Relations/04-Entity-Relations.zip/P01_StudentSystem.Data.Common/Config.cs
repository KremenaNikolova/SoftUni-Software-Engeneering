﻿namespace P01_StudentSystem.Data.Common
{
    public static class DbConfig
    {
        public static string ConnectionString = @"Server=ARADIA;Database=Bet366;Integrated Security=True;TrustServerCertificate=True;";
    }
}