﻿namespace P02_FootballBetting.Data.Common;

public class DbConfig
{
    public const string ConnectionString = @"Server=Aradia;Database=WinBetNever007;Integrated Security=True;TrustServerCertificate=True";
}