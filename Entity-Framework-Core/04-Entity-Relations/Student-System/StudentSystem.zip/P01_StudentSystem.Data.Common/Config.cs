﻿namespace P01_StudentSystem.Data.Common
{
    public static class DbConfig
    {
        public static string ConnectionString = @"Server=ARADIA;Database=Alohomora;Integrated Security=True;TrustServerCertificate=True;";
    }
}