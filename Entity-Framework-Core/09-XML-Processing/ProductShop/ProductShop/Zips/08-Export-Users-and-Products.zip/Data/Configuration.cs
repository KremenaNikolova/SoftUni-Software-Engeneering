﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=ARADIA;Database=ProductShop;Integrated Security=True;Encrypt=False";
    }
}
