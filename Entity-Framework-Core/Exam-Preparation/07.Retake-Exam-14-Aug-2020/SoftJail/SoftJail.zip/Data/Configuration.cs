﻿namespace SoftJail.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ARADIA;Database=SoftJail;Integrated Security=True;Encrypt=False;";
    }
}
