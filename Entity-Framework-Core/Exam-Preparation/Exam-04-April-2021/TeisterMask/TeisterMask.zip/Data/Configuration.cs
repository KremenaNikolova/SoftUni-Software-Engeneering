﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ARADIA;Database=TeisterMaskExam;Integrated Security=True;Encrypt=False";
    }
}
