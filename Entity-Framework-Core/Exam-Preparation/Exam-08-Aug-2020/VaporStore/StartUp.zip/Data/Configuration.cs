﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=ARADIA;Database=VaporStore;Integrated Security=True;Encrypt=False";
    }
}