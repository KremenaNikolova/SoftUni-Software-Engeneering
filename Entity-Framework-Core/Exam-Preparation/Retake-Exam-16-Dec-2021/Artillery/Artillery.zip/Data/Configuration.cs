﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=ARADIA;Database=Artillery;Integrated Security=True;Encrypt=False";
    }
}
