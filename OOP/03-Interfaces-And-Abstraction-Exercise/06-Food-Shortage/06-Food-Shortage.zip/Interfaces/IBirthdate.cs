﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday.Interfaces
{
    public interface IBirthdate : IID
    {
        string Birthdate { get; }
    }
}
