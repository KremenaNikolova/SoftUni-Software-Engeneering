﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday.Interfaces
{
    public interface IGroup :IIdentify
    {
        string Group { get; }

    }
}
