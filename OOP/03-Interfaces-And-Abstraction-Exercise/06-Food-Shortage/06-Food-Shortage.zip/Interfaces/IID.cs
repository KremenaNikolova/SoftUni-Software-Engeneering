﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Birthday.Interfaces
{
    public interface IID :IIdentify
    {
        string ID { get; }
    }
}
