﻿namespace CommandPattern.Utilities.Contracts
{
    public interface ICommandInterpreter
    {
        string Read(string args);
    }
}
